package pckagdemtest;

import java.awt.Component;

public class DemoOption extends Component {

}
