package pckagdemtest;

public class InvalidTokenError extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
