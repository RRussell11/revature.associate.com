package pckagdemtest;

public class UnsortedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
