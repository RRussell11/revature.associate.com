/*
 * 
 * 
 */

package pckagdemtest;

	import java.awt.*;
	import javax.swing.*;
	import java.awt.event.*;
	import java.util.Scanner;
	public class DemoQuickOption extends JPanel {//SimpleBarChart
	/**
		 * 
		 */
		
		private static final long serialVersionUID = 1L;
	private double[] value11;
	private String[] languages11;
	private String title;
	public DemoQuickOption(double[] val, String[] lang, String t) {
	languages11 = lang;
	value11 = val;
	title = t;
	}
	public void paintComponent(Graphics graphics) {
	super.paintComponent(graphics);
	if (value11 == null || value11.length == 0)
	return;
	double minValue = 0;
	double maxValue = 0;
	for (int i = 0; i < value11.length; i++) {
	if (minValue > value11[i])
	minValue = value11[i];
	if (maxValue < value11[i])
	maxValue = value11[i];
	}
	Dimension dim = getSize();
	int clientWidth = dim.width;
	int clientHeight = dim.height;
	int barWidth = clientWidth / value11.length;
	Font titleFont = new Font("Book Antiqua", Font.BOLD, 15);
	FontMetrics titleFontMetrics = graphics.getFontMetrics(titleFont);
	Font labelFont = new Font("Book Antiqua", Font.PLAIN, 10);
	FontMetrics labelFontMetrics = graphics.getFontMetrics(labelFont);
	int titleWidth = titleFontMetrics.stringWidth(title);
	int q = titleFontMetrics.getAscent();
	int p = (clientWidth - titleWidth) / 2;
	graphics.setFont(titleFont);
	graphics.drawString(title, p, q);
	int top = titleFontMetrics.getHeight();
	int bottom = labelFontMetrics.getHeight();
	if (maxValue == minValue)
	return;
	double scale = (clientHeight - top - bottom) / (maxValue - minValue);
	q = clientHeight - labelFontMetrics.getDescent();
	graphics.setFont(labelFont);
	for (int j = 0; j < value11.length; j++) {
	int valueP = j * barWidth + 1;
	int valueQ = top;
	int height = (int) (value11[j] * scale);
	if (value11[j] >= 0)
	valueQ += (int) ((maxValue - value11[j]) * scale);
	else {
	valueQ += (int) (maxValue * scale);
	height = -height;
	}
	graphics.setColor(Color.blue);
	graphics.fillRect(valueP, valueQ, barWidth - 2, height);
	graphics.setColor(Color.black);
	graphics.drawRect(valueP, valueQ, barWidth - 2, height);
	int labelWidth = labelFontMetrics.stringWidth(languages11[j]);
	p = j * barWidth + (barWidth - labelWidth) / 2;
	graphics.drawString(languages11[j], p, q);
	}
	}
	public static void main(String[] args) {
	   System.out.println("Which graph would you like to see?");
	   System.out.println("Quicksort=q, MergeSort=m, InsertionSort=i, SelectionSort=s");
	JFrame frame = new JFrame();
	frame.setSize(1000, 1000);
	Scanner scan=new Scanner(System.in);
	String input=scan.next();
	if(input.equals("q"))
	{
	double[] value= new double[15];
	String[] languages = new String[15];
	value[0] =2;
	value[1]=1;
	value[2]=73/10;
	languages[0] = "Comparison 50000";
	languages[1]="Swap 50000";
	languages[2]=" Time 50000";

	value[3] =2;
	value[4]=1;
	value[5]=226/10;
	languages[3] = "Comparison 100000";
	languages[4]="Swap 100000";
	languages[5]=" Time 100000";
	  
	value[6] =2;
	value[7]=1;
	value[8]=643/10;
	languages[6] = "Comparison 20000";
	languages[7]= "Swap 200000";
	languages[8]=" Time 200000";
	  
	value[9] =2;
	value[10]=1;
	value[11]=1238/10;
	languages[9] = "Comparison 300000";
	languages[10]="Swap 300000";
	languages[11]=" Time 50000";
	  
	value[12] =2;
	value[13]=1;
	value[14]=2929/10;
	languages[12] = "Comparison 400000";
	languages[13]="Swap 400000";
	languages[14]="Time 400000";
	frame.getContentPane().add(new DemoQuickOption (value, languages,
	"Quicksort bar chart"));
	WindowListener winListener = new WindowAdapter() {
	public void windowClosing(WindowEvent event) {
	System.exit(0);
	}
	};
	frame.addWindowListener(winListener);
	frame.setVisible(true);
	}
	if(input.equals("m"))
	{
	   double[] value= new double[15];
	   String[] languages = new String[15];
	   value[0] =1;
	   value[1]=1;
	   value[2]=210000/1000;
	   languages[0] = "Comparison 50000";
	   languages[1]="Swap 50000";
	   languages[2]=" Time 50000";
	     
	   value[3] =1;
	   value[4]=1;
	   value[5]=32000/1000;
	   languages[3] = "Comparison 100000";
	   languages[4]="Swap 100000";
	   languages[5]=" Time 100000";
	  
	   value[6] =1;
	   value[7]=1;
	   value[8]=130000/1000;
	   languages[6] = "Comparison 200000";
	   languages[7]="Swap 200000";
	   languages[8]="Time 200000";
	  
	   value[9] =1;
	   value[10]=1;
	   value[11]=200000/1000;
	   languages[9] = "Comparison 300000";
	   languages[10]="Swap 300000";
	   languages[11]=" Time 50000";
	  
	   value[12] =1;
	   value[13]=1;
	   value[14]=540000/1000;
	   languages[12] = "Comparison 400000";
	   languages[13]="Swap 400000";
	   languages[14]=" Time 400000";
	   frame.getContentPane().add(new DemoQuickOption(value, languages,
	   "MergeSort bar chart"));
	     
	   WindowListener winListener = new WindowAdapter() {
	   public void windowClosing(WindowEvent event) {
	   System.exit(0);
	   }
	   };{
	   frame.addWindowListener(winListener);
	   frame.setVisible(true);
	   }
	if(input.equals("i"))
	{
	   double[] value1= new double[15];
	   String[] languages1 = new String[15];
	   value[0] =2;
	   value[1]=1;
	   value[2]=73/10;
	   languages[0] = "Comparison 50000";
	   languages[1]="Swap 50000";
	   languages[2]=" Time 50000";
	     
	   value[3] =2;
	   value[4]=1;
	   value[5]=226/10;
	   languages[3] = "Comparison 100000";
	   languages[4]="Swap 100000";
	   languages[5]=" Time 100000";
	  
	   value[6] =2;
	   value[7]=1;
	   value[8]=643/10;
	   languages[6] = "Comparison 200000";
	   languages[7]="Swap 200000";
	   languages[8]="Time 200000";
	  
	   value[9] =2;
	   value[10]=1;
	   value[11]=1238/10;
	   languages[9] = "Comparison 300000";
	   languages[10]="Swap 300000";
	   languages[11]=" Time 50000";
	  
	   value[12] =2;
	   value[13]=1;
	   value[14]=2929/10;
	   languages[12] = "Comparison 400000";
	   languages[13]="Swap 400000";
	   languages[14]=" Time 400000";
	   frame.getContentPane().add(new DemoQuickOption (value, languages,
	   "InsertionSort bar chart"));
	     
	   WindowListener winListener1 = new WindowAdapter() {
	   public void windowClosing(WindowEvent event) {
	   System.exit(0);
	   }
	   };
	   frame.addWindowListener(winListener);
	   frame.setVisible(true);
	   }
	if(input.equals("s"))
	{
	   double[] value1= new double[15];
	   String[] languages1 = new String[15];
	   value[0] =2;
	   value[1]=1;
	   value[2]=73/10;
	   languages[0] = "Comparison 50000";
	   languages[1]="Swap 50000";
	   languages[2]=" Time 50000";
	     
	   value[3] =2;
	   value[4]=1;
	   value[5]=226/10;
	   languages[3] = "Comparison 100000";
	   languages[4]="Swap 100000";
	   languages[5]=" Time 100000";
	  
	   value[6] =2;
	   value[7]=1;
	   value[8]=643/10;
	   languages[6] = "Comparison 200000";
	   languages[7]="Swap 200000";
	   languages[8]="Time 200000";
	  
	   value[9] =2;
	   value[10]=1;
	   value[11]=1238/10;
	   languages[9] = "Comparison 300000";
	   languages[10]="Swap 300000";
	   languages[11]=" Time 50000";
	  
	   value[12] =2;
	   value[13]=1;
	   value[14]=2929/10;
	   languages[12] = "Comparison 400000";
	   languages[13]="Swap 400000";
	   languages[14]=" Time 400000";
	   frame.getContentPane().add(new DemoQuickOption(value, languages,
	   "Selection Sort bar chart"));
	     
	   WindowListener winListener1 = new WindowAdapter() {
	   public void windowClosing(WindowEvent event) {
	   System.exit(0);
	   }
	   };
	   frame.addWindowListener(winListener);
	   frame.setVisible(true);
	   }
	else
	   System.out.println("program terminated");
	}
	
	//View comments (1)  
	//Show more answers [+]
	
}}